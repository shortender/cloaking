@extends('layouts.base')

@section('content')
<h2>Notice</h2>
<h4>{{$message}}</h4>
@endsection
