<table id="{{$table_id}}" class="table table-hover">
    <thead>
        <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Created At</th>
            <th>Activated</th>
            <th>API</th>
            <th>Role</th>
            <th>Delete</th>
        </tr>
    </thead>
</table>
