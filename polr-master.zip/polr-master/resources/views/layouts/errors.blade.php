@extends('layouts.base')

@section('meta')
<meta http-equiv="Cache-Control" content="no-cache, no-store, max-age=0, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta name="robots" content="noindex" />
@endsection
