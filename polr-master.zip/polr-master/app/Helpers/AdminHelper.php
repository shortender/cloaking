<?php
namespace App\Helpers;

class AdminHelper {
    public static function pass() {
        
    }
}
