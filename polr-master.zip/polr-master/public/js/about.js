$('#gpl-license').hide();
$('.license-btn').click(function () {
    $('#gpl-license').slideDown();
    $('.license-btn').slideUp();
});
