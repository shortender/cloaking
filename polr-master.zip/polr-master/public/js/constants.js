/* Polr JS Constants */

const BASE_API_PATH = '/api/v2/';
