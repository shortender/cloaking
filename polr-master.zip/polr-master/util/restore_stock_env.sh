mv .env .env.bak
wget https://raw.githubusercontent.com/cydrobolt/polr/master/.env.setup
echo "Done!"
