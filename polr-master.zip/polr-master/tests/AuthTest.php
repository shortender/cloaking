<?php

class AuthTest extends TestCase
{
    /**
     * Test Authentication (sign up and sign in)
     *
     * @return void
     */
    public function testLogin() {
        // $this->visit('/')
        //      ->type('polrci', 'username')
        //      ->type('polrci', 'password ')
        //      ->press('Sign In')
        //      ->dontSee('name="login" value="Sign In" />')
        //      ->see('>Dashboard</a>');
    }
}
