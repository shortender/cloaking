# Contributors
----------------

Polr was written and is maintained by [Chaoyi Zha](https://cydrobolt.com),
but many other contributors have submitted code.
Thank you to all who have submitted code, documentation, or bug reports to help make Polr
a better project.

[Contributors](https://github.com/cydrobolt/polr/graphs/contributors)
