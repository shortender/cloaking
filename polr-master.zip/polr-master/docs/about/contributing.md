# Contributing
------------------

Polr's source is available on GitHub, at [cydrobolt/polr](https://github.com/cydrobolt/polr)
If you are familiar with PHP or any of the other technologies we use, your contribution would be greatly appreciated. We operate an IRC channel (`#polr`) on `irc.freenode.net:6667` for
contributor collaboration and user support.

For a list of tasks that may need help on, see [issues on GitHub](https://github.com/cydrobolt/polr/issues)
